import pygame

pygame.init() #초기화 (중요함)

#화면 크기 설정
screen_width = 480 #가로
screen_height = 640 #세로 크기
screen = pygame.display.set_mode((screen_width , screen_height))

# 화면 타이틀 설정
pygame.display.set_caption("공 쪼개기 게임") #게임 이름이 됩니다.


# 배경 이미지 불러오기
background = pygame.image.load("D:/Program_workspace/씨애랑20 소전/pygame_basic/background.png") #이미지 파일 불러오기

# 이벤트 루프
running = True # 게임의 진행 확인하기 
while running : 
    for event in pygame.event.get(): # event를 통해 사용자의 마우스 움직임을 파악 
        if event.type == pygame.QUIT : #창이 닫히는지 확인 event는 말그대로 사용장의 액션을 뜻함
            running = False

    #screen.fill((0,0,255)) #rgb값을 줘야함  백그라운드 이미지로 원하는 색상을 직관적으로 보여주기
    
    screen.blit(background, (0, 0)) #좌표의 기준은 실행창의 왼쪽 위 / 배경그리기

    pygame.display.update() #화면을 그려주는 동작을 실행! 

# pygame 종료
pygame.quit()