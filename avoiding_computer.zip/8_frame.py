#유투브 나도코딩영상을 기반으로 작성했습니다.

import pygame
#######################기본베이스######################################
pygame.init() #초기화 (중요함)

#화면 크기 설정
screen_width = 480 #가로
screen_height = 640 #세로 크기
screen = pygame.display.set_mode((screen_width , screen_height))

# 화면 타이틀 설정
pygame.display.set_caption("미니 게임") #게임 이름이 됩니다.

# FPS
clock = pygame.time.Clock()
###########################기본베이스#####################################

# 1. 사용자 게임 설정(배경, 게림 이미지 , 좌표, 속도, 폰트)

# 이벤트 루프
running = True # 게임의 진행 확인하기 
while running : #while ~게임이 실행중일때 
    dt = clock.tick(144) #게임화면의 초당 프레임을 설정

    
    # 2. 이벤트 처리 
    for event in pygame.event.get(): # event를 통해 사용자의 마우스 움직임을 파악 
        if event.type == pygame.QUIT : #창이 닫히는지 확인 event는 말그대로 사용장의 액션을 뜻함
            running = False #게임이 진행중인지 확인

       
    
    # 3.게임 캐릭터 위치 정의
    

    # 4. 충돌처리

    # 5. 화면에 그리기 표출 

    pygame.display.update() #화면을 그려주는 동작을(업데이트) 실행! 



# pygame 종료
pygame.quit()