"""
이 소스파일은 게임의 창이나 기반을 토대로 만들고 있습니다. pygame을 import해서 사용하고있습니다
"""

import pygame

pygame.init() #초기화 (중요함)

#화면 크기 설정
screen_width = 480 #가로
screen_height = 640 #세로 크기
screen = pygame.display.set_mode((screen_width , screen_height))

# 화면 타이틀 설정
pygame.display.set_caption("sm game") #게임 이름이 됩니다.

# 이벤트 루프
running = True # 게임의 진행 확인하기 
while running : 
    for event in pygame.event.get(): # event를 통해 사용자의 마우스 움직임을 파악 
        if event.type == pygame.QUIT : #창이 닫히는지 확인 event는 말그대로 사용장의 액션을 뜻함
            running = False

# pygame 종료
pygame.quit()