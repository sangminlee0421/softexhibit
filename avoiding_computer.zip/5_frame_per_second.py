#유투브 나도코딩영상을 기반으로 작성했습니다.

import pygame

pygame.init() #초기화 (중요함)

#화면 크기 설정
screen_width = 480 #가로
screen_height = 640 #세로 크기
screen = pygame.display.set_mode((screen_width , screen_height))

# 화면 타이틀 설정
pygame.display.set_caption("공 쪼개기 게임") #게임 이름이 됩니다.

# FPS
clock = pygame.time.Clock()

# 배경 이미지 불러오기
background = pygame.image.load("D:/Program_workspace/씨애랑20 소전/pygame_basic/background.png") #이미지 파일 불러오기

# 캐릭터 불러 오기
character = pygame.image.load("D:\Program_workspace\씨애랑20 소전\pygame_basic\character.png")
character_size = character.get_rect().size  #캐릭터 이미지 크기를 구해옴
character_width = character_size[0] # 캐릭터의 가로크기
character_height = character_size[1] # 캐릭터의 세로크기
character_x_pos = (screen_width /2 ) - (character_width / 2) # 화면 가로의 절반 크기에 해당하는곳에 기본포지션 왼쪽과 오른쪽 둘다 해줌
character_y_pos = screen_height - character_height #화면 세로 크기 가장 아래에 해당하는곳에 기본포지션(스크린에서 빼줘야 겹치지 않고 보인다.)

# 캐릭터가 이동할 좌표값
to_x = 0
to_y = 0

#캐릭터 이동속도 
character_speed = 0.6

# 이벤트 루프
running = True # 게임의 진행 확인하기 
while running : #while ~게임이 실행중일때 
    dt = clock.tick(144) #게임화면의 초당 프레임을 설정

    print("fps : " + str(clock.get_fps())) #fps를 나타냄

    for event in pygame.event.get(): # event를 통해 사용자의 마우스 움직임을 파악 
        if event.type == pygame.QUIT : #창이 닫히는지 확인 event는 말그대로 사용장의 액션을 뜻함
            running = False #게임이 진행중인지 확인

        if event.type == pygame.KEYDOWN : # 키보드키가 입력되었는지 확인
            if event.key == pygame.K_LEFT : # 키가 왼쪽으로 움직여짐
                to_x -= character_speed # to_x = to_x -5 //x좌표값이 움직임
            elif event.key == pygame.K_RIGHT :
                to_x += character_speed
            elif event.key == pygame.K_UP :
                to_y -= character_speed
            elif event.key == pygame.K_DOWN :
                to_y += character_speed

        if event.type == pygame.KEYUP : #방향키 입력이 없을때 멈추는것 
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT :
                to_x = 0
            elif event.key == pygame.K_UP or event.key == pygame.K_DOWN : 
                to_y = 0

    character_x_pos += to_x * dt
    character_y_pos += to_y * dt #dt값을 곱해주는 이유는 프레임값은 변해도 이동속도는 같게 유지하도록

    #가로의 화면 경계값 처리
    if character_x_pos < 0 :
        character_x_pos = 0
    elif character_x_pos > screen_width - character_width :
        character_x_pos = screen_width - character_width

    #세로의 화면 경계값 처리
    if character_y_pos < 0 :
        character_y_pos = 0
    elif character_y_pos > screen_height - character_height :
        character_y_pos = screen_height - character_height

    screen.blit(background, (0, 0)) #좌표의 기준은 실행창의 왼쪽 위 / 배경그리기

    screen.blit(character , (character_x_pos, character_y_pos)) # 캐릭터 그리기

    pygame.display.update() #화면을 그려주는 동작을 실행! 

# pygame 종료
pygame.quit()