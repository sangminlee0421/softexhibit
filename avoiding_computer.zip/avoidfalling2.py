
import random
import pygame

#######################기본베이스######################################
pygame.init() #초기화 (중요함)

#화면 크기 설정
screen_width = 640 #가로
screen_height = 640 #세로 크기
screen = pygame.display.set_mode((screen_width , screen_height))

# 화면 타이틀 설정
pygame.display.set_caption("컴퓨터 피하기") #게임 이름이 됩니다.

# FPS
clock = pygame.time.Clock()
###########################기본베이스#####################################

# 1. 사용자 게임 설정(배경, 게림 이미지 , 좌표, 속도, 폰트)
# 배경만들기
background = pygame.image.load("D:\Program_workspace\씨애랑20 소전\pygame_basic\\newbackground.png")


#캐릭터 만들기
character = pygame.image.load("D:\Program_workspace\씨애랑20 소전\pygame_basic\character_2.png")
character_size = character.get_rect().size #캐릭터 이미지 크기를 불러온다 
character_width = character_size[0] 
character_height = character_size[1] # 시작 사이즈
character_x_pos = (screen_width /2) - (character_width / 2) #가로축의 처음 출발위치
character_y_pos = (screen_height) - character_height # 세로축의 처음 출발 위치

#이동 위치
to_x = 0 #캐릭터가 이동할 좌표값
character_speed = 5 # 캐릭터의 초기 스피드 

# 낙하물 만들기 
falling = pygame.image.load("D:\Program_workspace\씨애랑20 소전\pygame_basic\\falling.png")
falling_size = falling.get_rect().size #낙하물 이미지 사이즈를 불러온다
falling_width = falling_size[0] 
falling_height = falling_size[1] # 시작 사이즈
falling_x_pos = random.randint(0, screen_width - falling_width) #가로축에서 랜덤으로 생성되게한다 
falling_y_pos = 0 # 세로축의 처음 출발 위치
falling_speed = 4

# 폰트 정의
game_font = pygame.font.Font(None, 50) #폰트 객체 생성(폰트, 크기)

# 이벤트 루프
running = True # 게임의 진행 확인하기 
while running : #while ~게임이 실행중일때 
    dt = clock.tick(144) #게임화면의 초당 프레임을 설정

    
    # 2. 이벤트 처리 
    for event in pygame.event.get(): # event를 통해 사용자의 마우스 움직임을 파악 
        if event.type == pygame.QUIT : #창이 닫히는지 확인 event는 말그대로 사용장의 액션을 뜻함
            running = False #게임이 진행중인지 확인

        if event.type == pygame.KEYDOWN : # 키보드키가 입력되었는지 확인
            if event.key == pygame.K_LEFT :  # 키가 왼쪽으로 움직여짐
                to_x -= character_speed  # to_x = to_x -5 //x좌표값이 움직임
            elif event.key == pygame.K_RIGHT :
                to_x += character_speed

        if event.type == pygame.KEYUP : #방향키 입력이 없을때 멈추는것
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT :
                to_x = 0
            
    
    # 3.게임 캐릭터 위치 정의
    character_x_pos += to_x 

    # 가로화면을 벗어나지 못하도록 처리해준다
    if character_x_pos < 0 :
        character_x_pos = 0
    elif character_x_pos > screen_width - character_width :
        character_x_pos = screen_width - character_width

    falling_y_pos += falling_speed
    if falling_y_pos > screen_height :
        falling_y_pos = 0 
        falling_x_pos = random.randint(0, screen_width - falling_width) 
        # 낙하물이 상부에서 생성된뒤 떨어지면 다시 돌아가게 만든다

    # 4. 충돌처리
    character_rect = character.get_rect()
    character_rect.left = character_x_pos
    character_rect.top = character_y_pos  # 캐릭터의 포지션을 rect를 사용해 업데이트 

    falling_rect = falling.get_rect()
    falling_rect.left = falling_x_pos
    falling_rect.top = falling_y_pos # 낙하물의 포지션을 똑같이 업데이트

    if character_rect.colliderect(falling_rect) :
        print ("충돌했어요!!")
        running = False


    # 5. 화면에 그리기 표출 
    screen.blit(background, (0,0) )
    screen.blit(character, (character_x_pos, character_y_pos))
    screen.blit(falling, (falling_x_pos, falling_y_pos))

    pygame.display.update() #화면을 그려주는 동작을(업데이트) 실행! 

#종료전에 텍스트를 보여주기 위해서 딜레이시간 부여
pygame.time.delay(2000) # 2초

# 게임 오버 출력하기

game_result = "GAME OVER!"

msg = game_font.render(game_result, True, (255, 255, 0))
msg_rect = msg.get_rect(center = (int(screen_width / 2), int(screen_height /2) ))
screen.blit(msg, msg_rect) # 화면에 표시해준다 
pygame.display.update() #화면을 그려주는 동작을(업데이트) 실행! 

pygame.time.delay(2000)
# 딜레이 로직

# pygame 종료
pygame.quit()